package com.flightinfosys.config;




public class MyBatisConfig {

//
}
